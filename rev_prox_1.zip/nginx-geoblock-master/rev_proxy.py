from flask import Flask, request, Response
import requests

app = Flask(__name__)

# Backend server URL
BACKEND_URL = "http://vulnapp.wikitoria.in"  # Change to your backend server

@app.route("/", defaults={"path": ""}, methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"])
@app.route("/<path:path>", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"])
def proxy(path):
    """
    Reverse proxy with SSL enabled.
    """
    target_url = f"{BACKEND_URL}/{path}"

    # Preserve headers (CSRF tokens, cookies, etc.)
    headers = {key: value for key, value in request.headers.items() if key.lower() not in ["host", "content-length"]}
    cookies = request.cookies
    data = request.get_data() if request.method in ["POST", "PUT", "PATCH"] else None

    # Forward the request
    response = requests.request(
        method=request.method,
        url=target_url,
        headers=headers,
        cookies=cookies,
        data=data,
        params=request.args,
        allow_redirects=False,
        stream=True
    )

    # Create Flask response with backend's response
    proxy_response = Response(response.raw, status=response.status_code)

    # Preserve response headers
    for key, value in response.headers.items():
        if key.lower() not in ["transfer-encoding", "content-encoding", "content-length"]:
            proxy_response.headers[key] = value

    # Preserve response cookies
    for cookie in response.cookies:
        proxy_response.set_cookie(
            key=cookie.name,
            value=cookie.value,
            path=cookie.path or "/",
            domain=cookie.domain if cookie.domain_specified else None,
            secure=cookie.secure,
            httponly=cookie.has_nonstandard_attr("httponly"),
            samesite=cookie.get_nonstandard_attr("samesite"),
            expires=cookie.expires if cookie.expires else None
        )

    return proxy_response

if __name__ == "__main__":
    # Run Flask with proper SSL certificates
    app.run(host="0.0.0.0", port=443, ssl_context=("fullchain.pem", "private.key"), debug=True)
